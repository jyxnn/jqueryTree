$(function(){
	// 规则
	$('.rule-btn').click(function(){
		$('.mask').show();
		$('.rule-img').show();
	})
	$('.close').click(function(){
		$('.mask').hide();
		$('.rule-img').hide();
	})
	// 开始测试
	$('.test-btn').click(function(){
		$('.mask').show();
		$('.phone-input').show();
	})
	// 确认测试
	$('.btn-ok').click(function(){
		var phone = $('.input-val').val();
		if(regPhone.test(phone)){
			// 获取题库
			sessionStorage.setItem('phone',phone)	
			// 调接口
			fetchlogin(phone)
			// window.location.href = './answers.html?num=1'
		}else{
			alertInfo('请输入正确的手机号')
		}
		console.log('value',phone);
		
	})
	
})