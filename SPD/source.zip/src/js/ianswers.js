$(function(){
	var subjectnum = GetQueryString('num'); // 题号
	console.log('subjectnum',subjectnum)
	// 解决刷新操作，该题已操作数据丢失 
	var myopt = JSON.parse(sessionStorage.getItem('myopt'))
	// 奖品类型
	var priceType = {
		1: 'prize1',
		2: 'prize2',
		3: 'prize3',
		4: 'prizeSpecial',
		5: 'prize0',
	}

	htmlHbs();

	// 题目渲染
	function htmlHbs(){
		// 原点高亮
		$('.dots li').eq(subjectnum-1).addClass('cur-dot');
		// 为最后一道题，更改按钮为提交
		if(subjectnum == 6){
			$('.anwser-box .footer-answer img').attr('src','img/submit-subject.png').removeClass('next-subject-btn').addClass('submit-subject-btn');
			fetchInitState();
		}
		
		// 获取数据
		var subjectInfo = getData('subject6')[subjectnum-1]; 
		subjectInfo.resOk = subjectInfo.resdes.ok;
		subjectInfo.resDes = subjectInfo.resdes.des;	
		var source = $('#hbsSubject').html();
		var tpl = Handlebars.compile(source);
		var html = tpl(subjectInfo);
		$('#subject').html(html)
		// 判断是否操作过,操作过，对应的选项样式修改，并展示答案说明
		if(myopt[subjectnum].opt){
			var index = myopt[subjectnum].sel;
			$('#subject li').eq(index).addClass(myopt[subjectnum].style)
			$('#subject .des-answers').show();
		}
	}	
	
	// 获取地址栏参数
	function GetQueryString(name){
	     var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)");
	     var r = window.location.search.substr(1).match(reg);
	     if(r!=null)return  unescape(r[2]); return null;
	}

	// 选择答案
	$('#subject').on('click','li',function(){
		console.log('click');
		// 判断是否未点击过
		if(!myopt[subjectnum].opt){
			// 更新为点击过
			myopt[subjectnum].opt = true;
			var score = $(this).data('score');
			var index = $(this).index(); // 返回同辈中的索引
			if(score == 1){
				myopt[subjectnum].sel = index;
				myopt[subjectnum].style = 'answer-success' 
				$(this).addClass('answer-success')
			}else{
				myopt[subjectnum].sel = index;
				myopt[subjectnum].style = 'answer-fail'
				$(this).addClass('answer-fail')
			}
			$('.anwser-box .des-answers').show();
			myopt.allscore = (myopt.allscore-0) + score;
			// 存储当前选中的答案
			updateSessionStorage();
		}else{
			console.log('caozuoguo')
		}
	});
	// 下一题
	$('.next-subject-btn').click(function(){
		// 进行过选择，进行跳转
		if(myopt[subjectnum].opt){
			window.location.href = './ianswers.html?num=' + ((subjectnum-0)+1)
			// window.location.replace('./answers.html?num=' + ((subjectnum-0)+1));
		}
	})
	// 提交操作
	$('.submit-subject-btn').click(function(){
		myopt.answerd = true; // 存储答题操作
		updateSessionStorage();
		fetchSubmit(); // 显示答题结果（未中奖、中奖礼盒）
	})
	// 提交之后的结果显示
	function submitRes(){
		if(myopt[subjectnum].opt){
			// fetchSubmit();
			console.log('score',myopt.allscore);
			//window.location.href = './answers.html?num=' + ((subjectnum-0)+1)
		}
	}
	// 答题失败结果
	$('.btn-again').click(function(){
		// login ->subject
		fetchlogin(sessionStorage.getItem('phone'))
	})
	$('.btn-toindex').click(function(){
		console.log(1)
		window.location.replace('./index.html')
	})
	
	// 答题成功结果
	$('.btn-prize-cj').click(function(){
		// 抽奖  已抽过 结果页，并销毁当前页面
		$(this).addClass('doudon'); // 抖动效果
		fetchPrize();
		
	})
	// 抽奖页面样式
	function prizeOptHtml(type){
		$('.'+ priceType[type]).show();
		// $('.mask').css('opacity',.95);
		$('.res-success').hide();
	}
	// 抽奖页面的确认按钮操作
	$('.btn-prize1').click(function(){
		var name = $('.prize1 .name').val();
		var qq = $('.prize1 .qq').val();
		var address = $('.prize1 .address').val();
		if(regInfo(name,address,qq)){
			fetchSubmitUserInfo({name:name,qq:qq,address:address})
		}
	})
	$('.btn-prize2').click(function(){
		var name = $('.prize2 .name').val();
		var address = $('.prize2 .address').val();
		if(regInfo(name,address,-1)){
			fetchSubmitUserInfo({name:name,address:address})
		}
	})
	$('.btn-prize3').click(function(){
		var name = $('.prize3 .name').val();
		var address = $('.prize3 .address').val();
		if(regInfo(name,address,-1)){
			fetchSubmitUserInfo({name:name,address:address})
		}
	})
	$('.btn-prizeSpecial').click(function(){
		window.location.href = './result.html'
	})
	// 校验
	function regInfo(name,address,qq){
		if(!name){
			alertInfo('请输入您的姓名');
			return false;
		}
		if(qq!=-1&&!regQQ.test(qq)){
			alertInfo('请输入正确的QQ号码');
			return false;
		}
		if(!address){
			alertInfo('请输入您的地址');
			return false;
		}
		return true;

	}
	// 更新题目操作变量的值
	function updateSessionStorage(){
		sessionStorage.setItem('myopt',JSON.stringify(myopt))
	}
	// fetch 提交答案
	function fetchSubmit(){
		// 数据处理
		var params = [];
		var selType = ['A','B','C','D']
		for(var key in myopt){
			if(myopt[key].id){
				var item = myopt[key];
				params.push({id:item.id,answer:selType[item.sel]})
			}
		}
		console.log('params',params)
		$.ajax({
			url:api+'api.php?action=answer',
			type:'post',
			data:{answer:params},
			dataType:'json'
		}).done(function(res){
			if(res.code == 200){
				var resdata = res.data;
				$('.mask').show();
				// 存储是否中奖
				if(resdata.right_count == 6){
					myopt.prized = true;
					// 全答对
					$('.anwser-box .res-success').show();
				}else{
					myopt.prized = false;
					$('.anwser-box .res-fail').show();
				}
				updateSessionStorage();
			}else{
				alertInfo(res.msg,'./index.html')
			}
			console.log('ianswers',res);
		})
	}
	// fetch 获取奖品
	function fetchPrize(){
 		$.ajax({
			url:api+'api.php?action=prize',
			dataType:'json'
		}).done(function(res){
			if(res.code == 200){
				var type = res.data.prize.yes_id;
				// 存储中了几等奖
				myopt.prizeOpt = type;
				updateSessionStorage();
				prizeOptHtml(type)
			}else{
				alertInfo(res.msg,'./index.html')
			}
		})
	}
	// fetch-model 最后一道题页面状态初始化（是否答题、是否中奖 是否抽奖 中了几等奖）
	function fetchInitState(){
		if(myopt.answerd){
			$('.mask').show();
			if(myopt.prized){ // 是否中奖
				if(myopt.prizeOpt){ // 是否抽奖
					prizeOptHtml(myopt.prizeOpt); // 中奖结果页面显示
				}else{
					// 礼盒
					$('.anwser-box .res-success').show();
				}
			}else{
				// 未中奖
				$('.anwser-box .res-fail').show();
			}
		}else{
			// 未答题，只显示题目
		}
	}
	// fetch 提交用户信息
	function fetchSubmitUserInfo(data){
		$.ajax({
			url: api + 'api.php?action=address',
			type:'post',
			data:data,
			dataType:'json'
		}).done(function(res){
			if(res.code==200){
				window.location.href = './result.html';
			}else{
				alertInfo(res.msg,'./index.html')
			}
		})
	}
	
})