var itemsObj = {
	1:{
		title:'浦发银行鑫盈利系列365天纯债1号，业绩比较基准4.8%，很心水，怎么办？<br>温馨提示：业绩比较基准不代表实际收益',
		answers:[
			{
				name:'A',
				des:'老司机，带带我',
				score:0 // 得分
			},{
				name:'B',
				des:'先告诉我风险多高',
				score:1
			}
		],
		resdes:{
			ok:'B',
			des:'理财非存款，市场有风险，投资需谨慎，广大投资者一定要选择匹配自身风险偏好和承受能力的理财产品哦。'
		}
	},
	2:{
		title:'FOF是什么？',
		answers:[
			{
				name:'A',
				des:'一篮子鸡',
				score:0 // 得分
			},{
				name:'B',
				des:'一篮子基金',
				score:1
			}
		],
		resdes:{
			ok:'B',
			des:'FOF（Fund of Funds），即基金中的基金。FOF将多只基金捆绑在一起，投资FoF等于同时投资多只基金，但比分别投资的成本大大降低了'
		}
	},
	3:{
		title:'快三十岁，还没有存款，咋整？',
		answers:[
			{
				name:'A',
				des:'去公安局修改年龄',
				score:0 // 得分
			},{
				name:'B',
				des:'开源节流，学会理财',
				score:1
			}
		],
		resdes:{
			ok:'B',
			des:'存钱不等于理财，但是要学会理财，一定要先懂得如何进行合理的财富规划。当财富积累到一定量之后，理财对财富的增值效果将会非常喜人。'
		}
	},
	4:{
		title:'已知：浦发银行鑫盈利系列182天纯债1号为固定持有期产品，到期自动还款<br>问：产品到期应该做什么？',
		answers:[
			{
				name:'A',
				des:'忘了赎回怎么办？不行，我要上个闹钟5点起床',
				score:1 // 得分
			},{
				name:'B',
				des:'睡到自然醒，等自动还款',
				score:0
			}
		],
		resdes:{
			ok:'A',
			des:'该产品固定持有期182天，持有期满自动还款，不用持有人再亲自赎回，省心省事儿。'
		}
	},
	5:{
		title:'以下哪个不是对“固定持有期”的解释？',
		answers:[
			{
				name:'A',
				des:'麦子熟了，到丰收的时候了',
				score:0 // 得分
			},{
				name:'B',
				des:'一周上班5天，多一天少一天都不行',
				score:0
			},{
				name:'C',
				des:'该毕业了，学校宿舍不让住了',
				score:0
			},{
				name:'D',
				des:'以上都不对',
				score:1
			}
		],
		resdes:{
			ok:'D',
			des:'购入固定持有期的理财产品，需要按照固定天数持有该产品，持有期满后自动还款，无需担心错过赎回。例如，浦发银行的悦盈利系列理财产品，固定持有期限有35天、90天、123天、184天、366天等多种安排，各种款式各种花色，任君选择。'
		}
	},
	6:{
		title:'现金管理类产品到底是什么鬼？',
		answers:[
			{
				name:'A',
				des:'赎回本金实时到账的“灵活鬼”（如，天添盈增利1号）',
				score:0 // 得分
			},{
				name:'B',
				des:'1万起买的“小气鬼”（如，天添盈增利2号）',
				score:0
			},{
				name:'C',
				des:'7天一周期自动滚动的 “机灵鬼”（如，周周享盈增利1号）',
				score:0
			},{
				name:'D',
				des:'以上都是',
				score:1
			}
		],
		resdes:{
			ok:'D',
			des:'现金管理类理财产品大多申赎起点低，流动性近似于活期储蓄，申购和赎回交易都非常方便。具有持有期长短随心、交易灵活、设置业绩比较基准便于掌握运作情况等特点，特别适合用来管理短期闲置资金。'
		}
	},
	7:{
		title:'行业“黑话”中的“央妈”是指？ ',
		answers:[
			{
				name:'A',
				des:'中央银行（央行）',
				score:1 // 得分
			},{
				name:'B',
				des:'驰名中外的下饭神器“老干妈”',
				score:0
			}
		],
		resdes:{
			ok:'A',
			des:'中央银行，是一国最高货币金融管理机构，在各国金融体系中居于主导地位。我国的中央银行是中国人民银行（简称央行或人行）。中国银行（简称中行）是国有商业银行之一，与建行、农行、工商银行等类似。'
		}
	},
	8:{
		title:'下面对“负利率”解读，哪一个更准确？',
		answers:[
			{
				name:'A',
				des:'强盗!我找你借钱是你的荣幸，借100还80',
				score:1 // 得分
			},{
				name:'B',
				des:'倒霉!养了一年的猪," 通胀"咬一口,哦豁,白养了',
				score:0
			}
		],
		resdes:{
			ok:'A',
			des:'负利率，是指物价飞涨，存银行的利率赶不上通货膨胀率，导致银行存款利率实际为负，故而原本10000元存银行一年以后，加上利息所得，能买的东西还是越来越少。'
		}
	},
	9:{
		title:'理财产品的流动性是什么意思？',
		answers:[
			{
				name:'A',
				des:'获得现金的便利程度，比如赎回资金到账速度。',
				score:1 // 得分
			},{
				name:'B',
				des:'确认过眼神，是水做的人',
				score:0
			}
		],
		resdes:{
			ok:'A',
			des:'流动性是指你能够获得现金的便利程度。在所有的金钱种类中，现金是最具有流动性的，因为可以立即得到它。相反，诸如房产、股票或者退休金账户里的资金，它们的流动性是比较差的，因为当你需要钱的时候很难在短时间内变现，甚至强制变现的时候可能会遭受损失。'
		}
	},
	10:{
		title:'熊猫债券，是什么？',
		answers:[
			{
				name:'A',
				des:'熊猫饲养员才能买的债券',
				score:0 // 得分
			},{
				name:'B',
				des:'境外机构在中国发行的人民币债券，入乡随俗换个中国特色的名字',
				score:1
			}
		],
		resdes:{
			ok:'B',
			des:'熊猫债券”是指国际多边金融机构在华发行的人民币债券。根据国际惯例，国外金融机构在一国发行债券时，一般以该国最具特征的吉祥物命名。2005年9月28日，国际多边金融机构首次获准在华发行人民币债券， 财政部部长金人庆把首发债券命名为“熊猫债券”。'
		}
	}
}
// 产生6个1-10随机题目，并保存
function createNums (len){
	var num10 = [1,2,3,4,5,6,7,8,9,10]
	var resSubject6 = []; // 保存生成的6个随机数
	for(var i = 0;i<len;i++){
		var num = Math.random()*num10.length;
		num = Math.floor(num) // 获取索引
		var item = itemsObj[num10[num]]
		resSubject6.push(item)
		num10.splice(num,1)
	}
	saveData('subject6',resSubject6)
	// sessionStorage.setItem('subject6',JSON.stringify(resSubject6))
}

function createSubject6 (arr){
	var resSubject6 = [];
	for(var i = 0;i<arr.length;i++){
		resSubject6.push(itemsObj[arr[i]])
	}
	console.log('666',resSubject6)
	saveData('subject6',resSubject6)
	// sessionStorage.setItem('subject6',JSON.stringify(resSubject6))
	// return resNum
}

// 题目相关操作初始化
function subjectoptinit(arr){
	var obj = {allscore:0}; // 默认得分
	for(var i = 1;i<=6;i++){
		obj[i] = {
			id:arr[i-1],
			opt:false, // 操作与否
			sel:'-1',  // 选中的答案索引，0开始
			style:''	// 对应的样式
		}
	}
	sessionStorage.setItem('myopt',JSON.stringify(obj))
}

// phone 规则
var regPhone = /^1[0-9]{10}$/;
var regQQ = /^[1-9][0-9]{4,14}$/;
// alert-fun
function alertInfo(message,href){
	weui.alert(message, function () {
		if(href){
			window.location.href = href;
		}
    }, {
        title: ''
    });
}

// 接口API
var api = './';  
// 部署 './''
//本地  'answer/'


// fetch 开始测试，是否三次
function fetchlogin(phone){
	$.ajax({
		url:api+'api.php?action=login',
		type:'post',
		data:{
			mobile:phone
		},
		dataType:'json'
	}).done(function(res){
		if(res.code==200){
			fetchSubject();
		}else if(res.code == 400){
			alertInfo('请输入正确的手机号')
		}else if(res.code == 401){
			alertInfo('今日答题次数已满3次，请明天再来吧！','./index.html')
		}
	})
}
// 获取6道题目
function fetchSubject(){
	$.ajax({
		url: api + 'api.php?action=questions',
		dataType:'json'
	}).done(function(res){
		var random6 = res.data.questions;
		createSubject6(random6)
		subjectoptinit(random6);
		window.location.href = './ianswers.html?num=1'
	})
}
function saveData(key,obj){
	sessionStorage.setItem(key,encode64(JSON.stringify(obj)))
}
function getData(key){
	return JSON.parse(decode64(sessionStorage.getItem(key)))
}
